//:displays the current year
//:[[year]]
$datum = date("Y");
return $datum;