//:sets a site cookie
//:[[site-cookie]]
return cookie::getInstance()->build_js();