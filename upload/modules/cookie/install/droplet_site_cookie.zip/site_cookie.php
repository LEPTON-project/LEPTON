//:sets a site cookie
//:[[site_cookie]]
return cookie::getInstance()->build_js();