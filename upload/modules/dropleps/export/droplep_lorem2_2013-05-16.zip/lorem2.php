//:Ein erweitertes Lorem-Droplep
//:Sets: Berthold,  fun, css
return "hello";