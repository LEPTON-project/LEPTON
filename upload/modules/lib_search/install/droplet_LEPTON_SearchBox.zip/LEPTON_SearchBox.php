//:Shows Search Box in the frontend
//:Usage: [[LEPTON_SearchBox]]  This Droplet will show a search box. You can use it within your template or at any WYSIWYG page section
if (SHOW_SEARCH) {
	global $oLEPTON;
	global $parser;
	global $loader;

if (!isset($parser))
{
 require_once( LEPTON_PATH."/modules/lib_twig/library.php" );
}
/**
 * Load Language file, load files frontend.js and frontend.css file via get_page_headers
 */
$lang = LEPTON_PATH."/modules/lib_search/languages/".LANGUAGE.".php";
include( file_exists($lang) ? $lang : LEPTON_PATH."/modules/lib_search/languages/EN.php" );
 
 $template = ($oLEPTON->page['template'] != "")
 ? $oLEPTON->page['template'] // current frontend-template for this page
 : DEFAULT_TEMPLATE  // default-frontend-template
 ;

 // set the template path and enable custom templates
if (file_exists( LEPTON_PATH.'/templates/'.$template.'/frontend/lib_search/templates/search.box.lte')) 
	{
	// custom template
	$loader->prependPath(LEPTON_PATH.'/templates/'.$template.'/frontend/lib_search/templates/');
	}
else 	{
	// standard module template
	$loader->prependPath(LEPTON_PATH.'/modules/lib_search/templates/');
	}	
  
// parse the search.box template
return $parser->render('search.box.lte', array('action' => LEPTON_URL.'/search/index.php', 'MOD_SEARCH'=> $MOD_SEARCH));
}
else {
    // the LEPTON search function is not enabled!
    return false;
}